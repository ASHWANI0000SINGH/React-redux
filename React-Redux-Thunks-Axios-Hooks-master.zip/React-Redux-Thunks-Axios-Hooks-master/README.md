### React, Redux thunk, Axios with Hooks

---

Simple example of Redux thunk with Axios in functional component with Hooks. It uses below libraries.

[x] React (CRA)
[x] React Redux
[x] Redux Thunk
[x] Axios
