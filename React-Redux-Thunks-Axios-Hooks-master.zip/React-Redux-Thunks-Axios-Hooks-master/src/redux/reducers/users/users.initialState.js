export default {
	isLoading: false,
	users: null,
	errorMessage: null,
};
